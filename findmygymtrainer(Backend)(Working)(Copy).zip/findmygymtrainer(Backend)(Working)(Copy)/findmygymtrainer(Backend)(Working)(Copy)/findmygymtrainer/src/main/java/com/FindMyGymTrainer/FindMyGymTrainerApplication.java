package com.FindMyGymTrainer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FindMyGymTrainerApplication {

	public static void main(String[] args) {
		SpringApplication.run(FindMyGymTrainerApplication.class, args);
	}

}
