
import gym1 from '../images/gym1.jpg';
import gym2 from '../images/gym2.jpg';
import gym3 from '../images/gym3.jpg';
import gym4 from '../images/gym4.webp';
import gym102 from '../images/gym102.jpg';
import gymMain from './gymMain.jpg'
import cycle from './cycle.jpg'
import crossfit from './crossfit.jpg'
import yoga from './yoga.jpg'
import notfound from './404.webp';
import safe from './safe&clean.webp'
import trainer1 from './trainer1.jpg'
import trainer2 from './trainer2.avif'
import hanuman from './hanuman.jpg'

  const data={hanuman,gymMain,gym102,gym1,gym2,gym3,gym4,cycle,crossfit,yoga,notfound,trainer1,trainer2,safe};


  export default data;