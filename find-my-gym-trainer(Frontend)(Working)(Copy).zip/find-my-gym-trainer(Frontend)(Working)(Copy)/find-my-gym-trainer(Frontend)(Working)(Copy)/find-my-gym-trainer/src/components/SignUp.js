import React, { useState } from 'react'
import Register from '../pages/normal register/Register'



const SignUp = () => {
   

  
    return (
      <div>
       
         <Register/>
      
      </div>
    );
}

export default SignUp
